
export interface Iproducts{
    id:string
    productName:string,
    prodDescription: string,
    price:string
}